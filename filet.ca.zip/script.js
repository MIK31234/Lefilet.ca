
function scrollToSection(id){
document.getElementById(id).scrollIntoView({behavior:'smooth'});
}

function chat(){
let input=document.getElementById('userInput').value.toLowerCase();
let chat=document.getElementById('chat');

if(input.includes('prix')) chat.innerText='100$ à 500$ par site';
else if(input.includes('client')) chat.innerText='Restaurants et commerces locaux';
else chat.innerText='Continue à apprendre l’IA!';
}
